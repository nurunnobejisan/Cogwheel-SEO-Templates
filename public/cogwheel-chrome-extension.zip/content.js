import{c as ne}from"./assets/pixelCalculator-BcAAV91H.js";import{a as ge}from"./assets/cogwheelTemplates-BO426zTk.js";const fe=/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,ye=/(?:\+?\d{1,3}[-.\s]?)?(?:\(\d{3}\)|\b\d{3})[-.\s]?\d{3}[-.\s]?\d{4}\b/g,be=/(https?:\/\/[^\s"'<>\)]+)(\?[^\s"'<>\)#]+)/gi;function v(t){if(!t)return{sanitized:"",emailsCount:0,phonesCount:0,queriesCount:0};let o=0,e=0,r=0;return{sanitized:t.replace(fe,()=>(o++,"[REDACTED_EMAIL]")).replace(ye,()=>(e++,"[REDACTED_PHONE]")).replace(be,(s,i)=>(r++,`${i}?redacted_query=true`)),emailsCount:o,phonesCount:e,queriesCount:r}}function N(t){if(!t)return{sanitizedUrl:"",hasRedactedQuery:!1};try{const o=new URL(t);return o.search&&o.search.length>1?(o.search="?redacted_query=true",{sanitizedUrl:o.toString(),hasRedactedQuery:!0}):{sanitizedUrl:t,hasRedactedQuery:!1}}catch{if(t.includes("?")){const[o,e]=t.split("?"),r=e.includes("#")?"#"+e.split("#")[1]:"";return{sanitizedUrl:`${o}?redacted_query=true${r}`,hasRedactedQuery:!0}}return{sanitizedUrl:t,hasRedactedQuery:!1}}}function L(t,o){if(!t||typeof t!="object")return;if(Array.isArray(t)){t.forEach(r=>L(r,o));return}const e=t;e["@type"]&&(typeof e["@type"]=="string"?o.add(e["@type"]):Array.isArray(e["@type"])&&e["@type"].forEach(r=>{typeof r=="string"&&o.add(r)})),Array.isArray(e["@graph"])&&e["@graph"].forEach(r=>L(r,o)),e.mainEntity&&L(e.mainEntity,o),e.itemListElement&&L(e.itemListElement,o)}function xe(t){const o=t.querySelector("main")||t.querySelector("article")||t.querySelector('[role="main"]')||t.body;if(!o)return"";const e=o.cloneNode(!0);return["nav","footer","header","aside","script","style","noscript","iframe","svg","button","form","dialog","select","textarea",'[aria-hidden="true"]',"[hidden]",".nav",".navbar",".footer",".menu",".sidebar",".cookie-banner",".modal"].forEach(l=>{try{e.querySelectorAll(l).forEach(s=>s.remove())}catch{}}),e.querySelectorAll("*").forEach(l=>{var s;const n=((s=l.getAttribute("style"))==null?void 0:s.toLowerCase())||"";(n.includes("display: none")||n.includes("display:none")||n.includes("visibility: hidden")||n.includes("visibility:hidden"))&&l.remove()}),(e.textContent||"").replace(/[ \t]+/g," ").replace(/\n\s*\n+/g,`

`).trim()}function we(t){const o=typeof document<"u"?document:null;if(!o)throw new Error("extractCapturedWebSample requires a valid Document context.");let e=0,r=0,u=0;const l=o.location?o.location.href:"",{sanitizedUrl:n,hasRedactedQuery:s}=N(l);s&&u++;const c=(o.location?o.location.hostname:"").toLowerCase(),g=o.querySelector('link[rel="canonical"]'),f=g?g.getAttribute("href")||"":n,{sanitizedUrl:y,hasRedactedQuery:p}=N(f);p&&u++;const b=o.title||"",k=v(b);e+=k.emailsCount,r+=k.phonesCount,u+=k.queriesCount;const S=o.querySelector('meta[name="description"]')||o.querySelector('meta[name="Description"]'),z=S&&S.getAttribute("content")||"",E=v(z);e+=E.emailsCount,r+=E.phonesCount,u+=E.queriesCount;const P=Array.from(o.querySelectorAll("h1")).map(h=>{var d;return((d=h.textContent)==null?void 0:d.trim())||""}).filter(Boolean).map(h=>{const d=v(h);return e+=d.emailsCount,r+=d.phonesCount,u+=d.queriesCount,d.sanitized}),_=Array.from(o.querySelectorAll("h2")).map(h=>{var d;return((d=h.textContent)==null?void 0:d.trim())||""}).filter(Boolean).map(h=>{const d=v(h);return e+=d.emailsCount,r+=d.phonesCount,u+=d.queriesCount,d.sanitized}),O=new Set;o.querySelectorAll('script[type="application/ld+json"]').forEach(h=>{try{const d=JSON.parse(h.textContent||"");L(d,O)}catch{}});const x=h=>{const d=o.querySelector(`meta[property="${h}"]`);return d&&d.getAttribute("content")||void 0},I=x("og:title"),R=x("og:description"),C=x("og:image"),q=x("og:url"),D={title:I?v(I).sanitized:void 0,description:R?v(R).sanitized:void 0,image:C?N(C).sanitizedUrl:void 0,type:x("og:type"),siteName:x("og:site_name"),url:q?N(q).sanitizedUrl:void 0},M=xe(o),w=v(M);e+=w.emailsCount,r+=w.phonesCount,u+=w.queriesCount;const U=w.sanitized?w.sanitized.split(/\s+/).filter(h=>h.length>0).length:0;return{url:n,domain:c,canonicalUrl:y,title:k.sanitized,metaDescription:E.sanitized,headings:{h1:P,h2:_},jsonLdTypes:Array.from(O),openGraph:D,mainContentText:w.sanitized,wordCount:U,extractedAt:new Date().toISOString(),sanitizationMetrics:{redactedEmailsCount:e,redactedPhonesCount:r,redactedQueryTokensCount:u}}}chrome.runtime.onMessage.addListener((t,o,e)=>{if(t.type==="CAPTURE_TRAINING_SAMPLE"){const r=we();return e({success:!0,sample:r}),!0}if(t.type==="EXTRACT_PAGE_DATA"){const r=Ae();return e({success:!0,data:r}),!0}if(t.type==="TOGGLE_OVERLAY")return ie(t.overlayType,t.enabled),e({success:!0}),!0;if(t.type==="CLEAR_ALL_OVERLAYS")return Ce(),e({success:!0}),!0;if(t.type==="INJECT_PREVIEW"){const r=Ee(t.payload);return e({success:!0,...r}),!0}if(t.type==="AUTO_FILL_CMS"){const r=Se(t.payload);return e({success:!0,result:r}),!0}if(t.type==="SCROLL_TO_ELEMENT"){const r=document.querySelector(t.selector);return r&&(r.scrollIntoView({behavior:"smooth",block:"center"}),r.style.outline="4px solid #10b981",setTimeout(()=>{r.style.outline=""},2500)),e({success:!0}),!0}});function Ae(){var F,J,Y,V,Z,X,K,ee,te,oe;if(typeof window<"u"&&(window.location.href.includes("Cogwheel-SEO-Templates")||document.title.includes("Cogwheel-SEO-Templates")))return ge;const t=document.title||"",o=((F=document.querySelector('meta[name="description"]'))==null?void 0:F.getAttribute("content"))||"",e=((J=document.querySelector('link[rel="canonical"]'))==null?void 0:J.getAttribute("href"))||"",r=((Y=document.querySelector('meta[name="robots"]'))==null?void 0:Y.getAttribute("content"))||"index, follow",u=document.documentElement.lang||"en",l=ne(t),n=ne(o),i=Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6")).map(a=>({tag:a.tagName.toUpperCase(),text:a.innerText.trim()})).filter(a=>a.text.length>0),c=i.filter(a=>a.tag==="H1").map(a=>a.text),g=i.filter(a=>a.tag==="H2").map(a=>a.text),f=i.filter(a=>a.tag==="H3").map(a=>a.text),y=Array.from(document.querySelectorAll("img"));let p=0,b=0;const k=y.slice(0,30).map(a=>{const m=a.getAttribute("alt")||"",T=a.getAttribute("src")||"",A=a.getAttribute("loading")||"eager";return m.trim()||p++,(a.naturalWidth>2e3||a.naturalHeight>2e3)&&b++,{src:T,alt:m,loading:A}}),S=document.body&&document.body.innerText||"",z=S.toLowerCase().replace(/[^a-z0-9\s]/g," ").trim().split(/\s+/).filter(a=>a.length>2),E=z.length,P=new Set(["the","and","for","with","that","this","from","you","are","have","our","all","your","can"]),_={};z.forEach(a=>{!P.has(a)&&a.length>=3&&(_[a]=(_[a]||0)+1)});const O=Object.entries(_).sort((a,m)=>m[1]-a[1]).slice(0,8).map(([a,m])=>({term:a,count:m,density:E>0?`${(m/E*100).toFixed(1)}%`:"0%"})),H=["pool","lazy river","beachfront","oceanfront","balcony","free wifi","hot breakfast","fitness center","spa","pet friendly","valet parking","ev charging","rooftop bar","restaurant","meeting rooms","suite","waterpark","concierge","golf","kitchenette"],x=[],I=S.toLowerCase();H.forEach(a=>{I.includes(a)&&x.push(a)});const R=Array.from(document.querySelectorAll('script[type="application/ld+json"]')),C=[];R.forEach(a=>{try{const m=JSON.parse(a.textContent||"{}");Array.isArray(m)?C.push(...m):m["@graph"]&&Array.isArray(m["@graph"])?C.push(...m["@graph"]):C.push(m)}catch{}});const q=Array.from(document.querySelectorAll("a[href]"));let D=0,M=0,w=0;const U=window.location.hostname,h=new Set;q.forEach(a=>{const m=a.getAttribute("href")||"";(a.getAttribute("rel")||"").includes("nofollow")&&w++;try{const A=new URL(m,window.location.origin);A.hostname===U||!A.hostname?(D++,A.pathname&&!A.pathname.match(/\.(jpg|png|pdf|svg|webp|css|js)$/i)&&h.add(A.href)):M++}catch{D++}});const d=[{platform:"TripAdvisor",regex:/tripadvisor\.com/i},{platform:"Google Maps",regex:/google\.com\/maps|maps\.app\.goo\.gl/i},{platform:"Yelp",regex:/yelp\.com/i},{platform:"Instagram",regex:/instagram\.com/i},{platform:"Facebook",regex:/facebook\.com/i},{platform:"Booking.com",regex:/booking\.com/i},{platform:"Expedia",regex:/expedia\.com/i}],B=[];q.forEach(a=>{const m=a.getAttribute("href")||"";d.forEach(T=>{T.regex.test(m)&&!B.some(A=>A.platform===T.platform)&&B.push({platform:T.platform,url:m})})});const re=/(\+?1[-.\s]?)?(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})/,W=S.match(re),se=W?W[0].trim():void 0,ae=/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/,G=S.match(ae),ce=G?G[0].trim():void 0;let Q;const $=document.querySelector("address, [itemprop='address'], .address, .hotel-address");$&&(Q=$.innerText.trim().replace(/\s+/g," "));const le=((V=document.querySelector('meta[property="og:title"]'))==null?void 0:V.getAttribute("content"))||t,de=((Z=document.querySelector('meta[property="og:description"]'))==null?void 0:Z.getAttribute("content"))||o,j=((X=document.querySelector('meta[property="og:image"]'))==null?void 0:X.getAttribute("content"))||"",ue=((K=document.querySelector('meta[name="twitter:card"]'))==null?void 0:K.getAttribute("content"))||void 0,me=((ee=document.querySelector('meta[name="twitter:title"]'))==null?void 0:ee.getAttribute("content"))||void 0,pe=((te=document.querySelector('meta[name="twitter:description"]'))==null?void 0:te.getAttribute("content"))||void 0,he=((oe=document.querySelector('meta[name="twitter:image"]'))==null?void 0:oe.getAttribute("content"))||void 0;return{url:window.location.href,origin:window.location.origin,pathname:window.location.pathname,protocol:window.location.protocol,hostname:window.location.hostname,title:t,titlePixelWidth:l,metaDesc:o,metaDescPixelWidth:n,metaRobots:r,language:u,canonical:e,h1Elements:c,h2Elements:g.slice(0,20),h3Elements:f.slice(0,20),allHeadings:i.slice(0,30),totalImages:y.length,imagesWithoutAlt:p,oversizedImages:b,imagesList:k,words:E,extractedAmenities:x,topKeywords:O,schemas:C,links:{internal:D,external:M,nofollow:w},internalUrls:Array.from(h).slice(0,25),hasViewport:!!document.querySelector('meta[name="viewport"]'),hasOgTitle:!!document.querySelector('meta[property="og:title"]'),hasOgImage:!!j,ogTitle:le,ogDescription:de,ogImage:j,twitterTags:{card:ue,title:me,description:pe,image:he},detectedNap:{phone:se,address:Q,email:ce},socialLinks:B}}function Ee(t){const o=[];if(t.title&&(document.title=t.title,o.push("Title Tag")),t.metaDesc){let e=document.querySelector('meta[name="description"]');e||(e=document.createElement("meta"),e.setAttribute("name","description"),document.head.appendChild(e)),e.setAttribute("content",t.metaDesc),o.push("Meta Description")}if(t.h1){const e=document.querySelector("h1");e&&(e.innerText=t.h1,e.style.outline="4px solid #10b981",e.style.transition="outline 0.4s ease",setTimeout(()=>{e.style.outline=""},3e3),o.push("H1 Headline"))}if(t.schemaJson){let e=document.getElementById("__cogwheel_preview_schema__");e||(e=document.createElement("script"),e.id="__cogwheel_preview_schema__",e.setAttribute("type","application/ld+json"),document.head.appendChild(e)),e.textContent=t.schemaJson,o.push("JSON-LD Schema")}return{injected:o}}function Se(t){const o=[];let e="Generic/DOM";const r=(p,b)=>{p.value=b,p.dispatchEvent(new Event("input",{bubbles:!0})),p.dispatchEvent(new Event("change",{bubbles:!0})),p.dispatchEvent(new Event("blur",{bubbles:!0}))},u=document.querySelector("#yoast-google-preview-title-metabox, #yoast_wpseo_title"),l=document.querySelector("#yoast-google-preview-description-metabox, #yoast_wpseo_metadesc");if(u||l)return e="WordPress/Yoast",u&&t.title&&(r(u,t.title),o.push("Yoast SEO Title")),l&&t.metaDesc&&(r(l,t.metaDesc),o.push("Yoast Meta Description")),{detectedCms:e,filledFields:o,success:o.length>0};const n=document.querySelector("#rank_math_title"),s=document.querySelector("#rank_math_description");if(n||s)return e="WordPress/RankMath",n&&t.title&&(r(n,t.title),o.push("Rank Math Title")),s&&t.metaDesc&&(r(s,t.metaDesc),o.push("Rank Math Description")),{detectedCms:e,filledFields:o,success:o.length>0};const i=document.querySelector(".editor-post-title__input, #title");i&&t.title&&(e="WordPress/Classic",r(i,t.title),o.push("Post/Page Title"));const c=document.querySelector('[data-automation-id="page-title-input"], input[name="title"]'),g=document.querySelector('[data-automation-id="page-description-input"], textarea[name="description"]');if(c||g)return e="Webflow",c&&t.title&&(r(c,t.title),o.push("Webflow SEO Title")),g&&t.metaDesc&&(r(g,t.metaDesc),o.push("Webflow Meta Description")),{detectedCms:e,filledFields:o,success:o.length>0};const f=document.querySelector("#seo-title, #page-title"),y=document.querySelector("#seo-description, #page-description");if(f||y)return e="Shopify",f&&t.title&&(r(f,t.title),o.push("Shopify SEO Title")),y&&t.metaDesc&&(r(y,t.metaDesc),o.push("Shopify Meta Description")),{detectedCms:e,filledFields:o,success:o.length>0};if(t.title&&(document.title=t.title,o.push("DOM Document Title")),t.metaDesc){let p=document.querySelector('meta[name="description"]');p||(p=document.createElement("meta"),p.setAttribute("name","description"),document.head.appendChild(p)),p.setAttribute("content",t.metaDesc),o.push("DOM Meta Description")}return{detectedCms:e,filledFields:o,success:o.length>0}}function ie(t,o){const e=t==="links"?"bookingLinks":t,r=`__cogwheel_${e}_overlay__`,u=document.getElementById(r);if(!o){if(u&&u.remove(),e==="headings")document.querySelectorAll(".cogwheel-heading-badge").forEach(n=>n.remove()),document.querySelectorAll("[data-cogwheel-headings]").forEach(n=>{n.style.outline="",n.removeAttribute("data-cogwheel-headings")});else if(e==="missingAlts")document.querySelectorAll(".cogwheel-alt-badge").forEach(n=>n.remove()),document.querySelectorAll("[data-cogwheel-missingAlts]").forEach(n=>{n.style.outline="",n.style.outlineOffset="",n.removeAttribute("data-cogwheel-missingAlts")});else if(e==="schemas"){const n=document.getElementById("cogwheel_schema_banner");n&&n.remove(),document.querySelectorAll("[data-cogwheel-schemas]").forEach(s=>{s.style.outline="",s.removeAttribute("data-cogwheel-schemas")})}else e==="bookingLinks"?(document.querySelectorAll(".cogwheel-booking-badge").forEach(n=>n.remove()),document.querySelectorAll("[data-cogwheel-bookingLinks]").forEach(n=>{n.style.outline="",n.removeAttribute("data-cogwheel-bookingLinks")})):e==="geoBlocks"&&(document.querySelectorAll(".cogwheel-geo-badge").forEach(n=>n.remove()),document.querySelectorAll("[data-cogwheel-geoBlocks]").forEach(n=>{n.style.outline="",n.style.outlineOffset="",n.removeAttribute("data-cogwheel-geoBlocks")}));return}let l=document.getElementById(r);if(l||(l=document.createElement("style"),l.id=r,document.head.appendChild(l)),e==="headings")l.textContent=`
      .cogwheel-heading-badge {
        position: absolute;
        top: -10px;
        left: 0;
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 10px;
        font-weight: 800;
        padding: 2px 6px;
        border-radius: 4px;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        pointer-events: none;
      }
      .cogwheel-badge-h1 { background: #10b981; }
      .cogwheel-badge-h1-dup { background: #ef4444; }
      .cogwheel-badge-h2 { background: #0284c7; }
      .cogwheel-badge-h3 { background: #8b5cf6; }
    `,Array.from(document.querySelectorAll("h1")).forEach((s,i)=>{s.setAttribute("data-cogwheel-headings","true"),s.style.position="relative",s.style.outline=i===0?"2.5px dashed #10b981":"3px solid #ef4444";const c=document.createElement("span");c.className=`cogwheel-heading-badge ${i===0?"cogwheel-badge-h1":"cogwheel-badge-h1-dup"}`,c.textContent=i===0?"H1 (Primary)":`H1 Duplicate #${i+1}`,s.appendChild(c)}),document.querySelectorAll("h2").forEach((s,i)=>{s.setAttribute("data-cogwheel-headings","true"),s.style.position="relative",s.style.outline="2px dotted #0284c7";const c=document.createElement("span");c.className="cogwheel-heading-badge cogwheel-badge-h2",c.textContent=`H2 #${i+1}`,s.appendChild(c)}),document.querySelectorAll("h3").forEach((s,i)=>{s.setAttribute("data-cogwheel-headings","true"),s.style.position="relative",s.style.outline="2px dotted #8b5cf6";const c=document.createElement("span");c.className="cogwheel-heading-badge cogwheel-badge-h3",c.textContent=`H3 #${i+1}`,s.appendChild(c)});else if(e==="missingAlts")l.textContent=`
      .cogwheel-alt-badge {
        position: absolute;
        top: 4px;
        left: 4px;
        z-index: 999999;
        background: #ef4444;
        color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 10px;
        font-weight: 800;
        padding: 3px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.4);
        pointer-events: none;
      }
    `,document.querySelectorAll("img").forEach(n=>{const s=n.getAttribute("alt");if(!s||s.trim()===""){n.setAttribute("data-cogwheel-missingAlts","true"),n.style.outline="3px solid #ef4444",n.style.outlineOffset="2px",n.parentElement&&getComputedStyle(n.parentElement).position==="static"&&(n.parentElement.style.position="relative");const i=document.createElement("span");i.className="cogwheel-alt-badge",i.textContent="MISSING ALT",n.parentElement&&n.parentElement.appendChild(i)}});else if(e==="schemas"){const n=document.getElementById("cogwheel_schema_banner");n&&n.remove();const s=Array.from(document.querySelectorAll('script[type="application/ld+json"]')),i=[];s.forEach(g=>{try{const f=JSON.parse(g.textContent||"{}");f["@type"]&&i.push(f["@type"]),Array.isArray(f["@graph"])&&f["@graph"].forEach(y=>{y["@type"]&&i.push(y["@type"])})}catch{}});const c=document.createElement("div");c.id="cogwheel_schema_banner",c.setAttribute("style",`
      position: fixed;
      top: 14px;
      right: 14px;
      z-index: 99999999;
      background: rgba(15, 23, 42, 0.95);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #ffffff;
      padding: 10px 14px;
      border-radius: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(8px);
      max-width: 320px;
      font-size: 11px;
    `),c.innerHTML=`
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 4px;">
        <span style="font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #34d399;">
          VALIDATED JSON-LD SCHEMA
        </span>
        <span style="font-size: 9px; font-weight: 700; color: #94a3b8;">
          ${s.length} script block${s.length===1?"":"s"}
        </span>
      </div>
      <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px;">
        ${i.length>0?i.map(g=>`<span style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #6ee7b7; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-family: monospace; font-size: 10px;">@type: ${g}</span>`).join(""):'<span style="background: rgba(245, 158, 11, 0.2); color: #fcd34d; padding: 2px 6px; border-radius: 4px; font-weight: 700;">No JSON-LD Schema Found</span>'}
      </div>
    `,document.body.appendChild(c)}else if(e==="bookingLinks"){l.textContent=`
      .cogwheel-booking-badge {
        position: absolute;
        top: -8px;
        right: 0;
        z-index: 999999;
        background: #10b981;
        color: #ffffff;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 9px;
        font-weight: 800;
        padding: 1px 5px;
        border-radius: 3px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        pointer-events: none;
      }
    `;const n=window.location.hostname,s=/book|reserv|stay|room|rate|checkout|check-avail|cart/i;document.querySelectorAll("a[href]").forEach(i=>{i.setAttribute("data-cogwheel-bookingLinks","true");const c=i.getAttribute("href")||"",g=i.textContent||"",f=s.test(c)||s.test(g);try{const y=new URL(c,window.location.origin),p=y.hostname===n||!y.hostname;if(f&&p){i.style.position="relative",i.style.outline="2.5px solid #10b981";const b=document.createElement("span");b.className="cogwheel-booking-badge",b.textContent="DIRECT BOOKING CTA",i.appendChild(b)}else p?i.style.outline="1.5px solid #0284c7":i.style.outline="1.5px dashed #f59e0b"}catch{i.style.outline="1.5px solid #0284c7"}})}else if(e==="geoBlocks"){l.textContent=`
      .cogwheel-geo-badge {
        position: absolute;
        top: 6px;
        left: 6px;
        z-index: 999999;
        background: #8b5cf6;
        color: #ffffff;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 10px;
        font-weight: 800;
        padding: 3px 7px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(139, 92, 246, 0.4);
        pointer-events: none;
      }
    `;const s=Array.from(document.querySelectorAll(`
      details,
      [data-faq],
      .faq,
      #faq,
      [id*="faq"],
      [class*="faq"],
      .amenities,
      #amenities,
      [id*="amenit"],
      .location,
      #location,
      [id*="location"],
      section[aria-label*="FAQ" i],
      section[aria-label*="Amenities" i],
      section[aria-label*="Location" i]
    `));document.querySelectorAll("h2, h3, h4").forEach(i=>{const c=(i.textContent||"").toLowerCase();(c.includes("faq")||c.includes("frequently asked")||c.includes("amenities")||c.includes("getting here")||c.includes("location")||c.includes("policies")||c.includes("check-in"))&&i.parentElement&&!s.includes(i.parentElement)&&s.push(i.parentElement)}),s.forEach(i=>{i.setAttribute("data-cogwheel-geoBlocks","true"),i.style.position="relative",i.style.outline="2.5px dashed #8b5cf6",i.style.outlineOffset="3px";const c=document.createElement("span");c.className="cogwheel-geo-badge",c.textContent="GEO AI KNOWLEDGE TARGET",i.appendChild(c)})}}function Ce(){["headings","missingAlts","schemas","bookingLinks","geoBlocks"].forEach(o=>ie(o,!1))}
