chrome.runtime.onMessage.addListener((t,d,a)=>{if(t.type==="EXTRACT_PAGE_DATA"){const l=C();return a({success:!0,data:l}),!0}if(t.type==="TOGGLE_OVERLAY")return I(t.overlayType,t.enabled),a({success:!0}),!0;if(t.type==="SCROLL_TO_ELEMENT"){const l=document.querySelector(t.selector);return l&&(l.scrollIntoView({behavior:"smooth",block:"center"}),l.style.outline="4px solid #10b981",setTimeout(()=>{l.style.outline=""},2500)),a({success:!0}),!0}});function C(){var y,b,w,A,x;const t=document.title||"",d=((y=document.querySelector('meta[name="description"]'))==null?void 0:y.getAttribute("content"))||"",a=((b=document.querySelector('link[rel="canonical"]'))==null?void 0:b.getAttribute("href"))||"",l=Array.from(document.querySelectorAll("h1")).map(o=>o.innerText.trim()).filter(Boolean),s=Array.from(document.querySelectorAll("h2")).map(o=>o.innerText.trim()).filter(Boolean),n=Array.from(document.querySelectorAll("h3")).map(o=>o.innerText.trim()).filter(Boolean),e=Array.from(document.querySelectorAll("img"));let c=0,r=0;e.forEach(o=>{const i=o.getAttribute("alt");(!i||i.trim()==="")&&c++,(o.naturalWidth>2e3||o.naturalHeight>2e3)&&r++});const S=(document.body&&document.body.innerText||"").trim().split(/\s+/).filter(Boolean).length,T=Array.from(document.querySelectorAll('script[type="application/ld+json"]')),u=[];T.forEach(o=>{try{const i=JSON.parse(o.textContent||"{}");Array.isArray(i)?u.push(...i):i["@graph"]&&Array.isArray(i["@graph"])?u.push(...i["@graph"]):u.push(i)}catch{}});const q=Array.from(document.querySelectorAll("a[href]"));let g=0,m=0,p=0;const v=window.location.hostname;q.forEach(o=>{const i=o.getAttribute("href")||"";(o.getAttribute("rel")||"").includes("nofollow")&&p++;try{const E=new URL(i,window.location.origin);E.hostname===v||!E.hostname?g++:m++}catch{g++}});const _=((w=document.querySelector('meta[property="og:title"]'))==null?void 0:w.getAttribute("content"))||t,k=((A=document.querySelector('meta[property="og:description"]'))==null?void 0:A.getAttribute("content"))||d,f=((x=document.querySelector('meta[property="og:image"]'))==null?void 0:x.getAttribute("content"))||"";return{url:window.location.href,origin:window.location.origin,pathname:window.location.pathname,protocol:window.location.protocol,hostname:window.location.hostname,title:t,metaDesc:d,canonical:a,h1Elements:l,h2Elements:s.slice(0,20),h3Elements:n.slice(0,20),totalImages:e.length,imagesWithoutAlt:c,oversizedImages:r,words:S,schemas:u,links:{internal:g,external:m,nofollow:p},hasViewport:!!document.querySelector('meta[name="viewport"]'),hasOgTitle:!!document.querySelector('meta[property="og:title"]'),hasOgImage:!!f,ogTitle:_,ogDescription:k,ogImage:f}}function I(t,d){const a=`__cogwheel_${t}_overlay__`,l=document.getElementById(a);if(!d){l&&l.remove(),document.querySelectorAll(`[data-cogwheel-${t}]`).forEach(n=>{n.style.outline="",n.removeAttribute(`data-cogwheel-${t}`)});return}let s=document.getElementById(a);if(s||(s=document.createElement("style"),s.id=a,document.head.appendChild(s)),t==="headings")s.textContent=`
      .cogwheel-heading-badge {
        position: absolute;
        top: -10px;
        left: 0;
        z-index: 999999;
        font-family: -apple-system, sans-serif;
        font-size: 10px;
        font-weight: 800;
        padding: 2px 6px;
        border-radius: 4px;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        pointer-events: none;
      }
      .cogwheel-badge-h1 { background: #10b981; }
      .cogwheel-badge-h1-dup { background: #ef4444; }
      .cogwheel-badge-h2 { background: #0284c7; }
      .cogwheel-badge-h3 { background: #8b5cf6; }
    `,Array.from(document.querySelectorAll("h1")).forEach((e,c)=>{e.setAttribute("data-cogwheel-headings","true"),e.style.position="relative",e.style.outline=c===0?"2px dashed #10b981":"3px solid #ef4444";const r=document.createElement("span");r.className=`cogwheel-heading-badge ${c===0?"cogwheel-badge-h1":"cogwheel-badge-h1-dup"}`,r.textContent=c===0?"H1 (Primary)":`H1 Duplicate #${c+1}`,e.appendChild(r)}),document.querySelectorAll("h2").forEach((e,c)=>{e.setAttribute("data-cogwheel-headings","true"),e.style.position="relative",e.style.outline="2px dotted #0284c7";const r=document.createElement("span");r.className="cogwheel-heading-badge cogwheel-badge-h2",r.textContent=`H2 #${c+1}`,e.appendChild(r)});else if(t==="missingAlts")s.textContent=`
      .cogwheel-alt-badge {
        position: absolute;
        bottom: 4px;
        left: 4px;
        z-index: 999999;
        background: #ef4444;
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        padding: 3px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.4);
      }
    `,document.querySelectorAll("img").forEach(n=>{const e=n.getAttribute("alt");(!e||e.trim()==="")&&(n.setAttribute("data-cogwheel-missingAlts","true"),n.style.outline="3px solid #ef4444",n.style.outlineOffset="2px")});else if(t==="links"){const n=window.location.hostname;document.querySelectorAll("a[href]").forEach(e=>{e.setAttribute("data-cogwheel-links","true");const c=e.getAttribute("href")||"",r=e.getAttribute("rel")||"";try{const h=new URL(c,window.location.origin);r.includes("nofollow")?e.style.outline="2px solid #f59e0b":h.hostname===n||!h.hostname?e.style.outline="1.5px solid #10b981":e.style.outline="1.5px solid #0284c7"}catch{e.style.outline="1.5px solid #10b981"}})}}
